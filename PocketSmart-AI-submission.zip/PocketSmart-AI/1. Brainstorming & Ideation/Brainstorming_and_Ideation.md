# Phase 1: Brainstorming & Ideation

## Problem statement
People planning a purchase or event across several needs, such as decorating a room, hosting a party or buying jewelry, face too many products, platforms and price ranges. They often overspend or waste hours comparing options because nothing splits one budget sensibly across categories.

## Proposed solution
**PocketSmart AI** takes a budget and a few preferences and uses Google's Gemini model to return budget-fitted recommendations, each with a price estimate, a reason, and a search link on a relevant platform (Amazon, Flipkart, IKEA, Swiggy, Zomato, OYO).

## Target users
- Students and young professionals furnishing a first home
- Families organising birthdays, weddings and get-togethers
- Shoppers choosing jewelry that matches an outfit and occasion

## Ideas considered
| Idea | Decision |
|---|---|
| One generic budget chatbot | Rejected. Answers were vague and not structured |
| Separate planners with tailored forms | **Chosen.** Forms collect the details each domain needs |
| Live scraping of shopping sites | Rejected. Sites block scraping and terms forbid it. Search links used instead |
| Image input for jewelry | **Chosen.** Outfit colours make matching more accurate |

## Core features
1. Home Interior Planner (rooms, lights, fans, dining tables, style)
2. Party Planner (guests, event type, venue; catering, decoration, entertainment, stay)
3. Jewelry Planner (occasion, style, optional outfit photo)
4. User registration and login
5. History of past recommendations
6. Default recommendations when the AI is unavailable

## Expected outcome
A user enters a budget and gets a structured, price-aware list in seconds, saved to their history.
