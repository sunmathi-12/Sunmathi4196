# Phase 8: Project Demonstration

**Demo video (Google Drive, access set to "Anyone with the link"):**
PASTE-YOUR-DRIVE-LINK-HERE

## What the video shows
1. Register and log in
2. Home planner with a real budget
3. Party planner
4. Jewelry planner with an outfit photo
5. History page
