# Phase 4: Project Planning

## Milestones and activities
| Milestone | Activities | Status |
|---|---|---|
| 1. Gemini AI initialization | Get API key; configure access; validate text and image calls | Done |
| 2. Core functionality | FastAPI setup; planner endpoints; login and register; modular code | Done |
| 3. Backend integration (main.py) | Routes, history, session routes, CORS, startup | Done |
| 4. UI development | Forms for three planners, result cards, auth pages | Done |
| 5. Testing & optimization | Test all planners, check budget adherence, validations, fallback | In progress |
| 6. Submission | GitHub repository, documentation, demo video, Google Form | In progress |

## Timeline
| Date | Work |
|---|---|
| Week 1 | Requirements, Gemini setup, prompt design |
| Week 2 | Backend, auth and planner routes |
| Week 3 | UI and integration |
| Final days | Testing, documentation, demo video |
| 30 Sep 2026 | Final submission deadline |

*Edit the dates and statuses above to match your own schedule.*

## Roles
[Your Name]: design, development, testing and documentation.

## Risks and mitigation
| Risk | Mitigation |
|---|---|
| Gemini API unavailable or key invalid | Fallback recommendations |
| AI returns malformed JSON | Response is validated and cleaned, fallback if unusable |
| Prices drift from real store prices | Labelled as estimates on every page |
| API key leaked | `.env` excluded through `.gitignore` |
