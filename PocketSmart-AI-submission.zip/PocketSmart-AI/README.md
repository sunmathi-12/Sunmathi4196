# PocketSmart AI: Your Smart Budget & Recommendation Assistant

A GenAI-powered web app that turns a budget into a shopping and planning list for **home interiors**, **parties** and **jewelry**, with picks from Amazon, Flipkart, IKEA, Swiggy, Zomato and OYO.

**Team / Student:** [Your Name], BSc CS (AI), Bharathiar University affiliated college
**Track:** AI-ML and GenAI

## Repository structure
| Folder | Contents |
|---|---|
| 1. Brainstorming & Ideation | Problem, idea, users |
| 2. Requirement Analysis | Functional and non-functional requirements, tech stack |
| 3. Project Design Phase | Architecture, data flow, API design |
| 4. Project Planning Phase | Milestones, activities, timeline |
| 5. Project Development Phase | Working source code |
| 6.Project Testing | Test cases and results |
| 7.Project Documentation | Final report and user guide |
| 8.Project Demonstration | Demo video link |

## Quick start
```
cd "5. Project Development Phase"
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
copy .env.example .env      (then add your Gemini API key)
python main.py
```
Open http://127.0.0.1:8000
