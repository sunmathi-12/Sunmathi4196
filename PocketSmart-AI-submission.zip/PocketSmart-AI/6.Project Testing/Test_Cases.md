# Phase 6: Project Testing

Fill in the **Result** column after you run each test, and add screenshots to this folder.

| ID | Scenario | Input | Expected | Result |
|---|---|---|---|---|
| T1 | Register | New username (3+ chars), password (6+) | Redirect to dashboard | |
| T2 | Register duplicate | Existing username | "That username is taken." | |
| T3 | Login wrong password | Valid user, wrong password | Error message shown | |
| T4 | Protected page | Open /history while logged out | Redirect to login | |
| T5 | Home planner | Budget 50000, Living Room + Kitchen, 4 lights, 2 fans | Cards with prices and store links | |
| T6 | Party planner | Budget 30000, 40 guests, Birthday | Catering, decoration, entertainment picks | |
| T7 | Jewelry, text only | Budget 15000, Wedding, Traditional | Jewelry picks from Amazon/Flipkart | |
| T8 | Jewelry with image | Same, with outfit photo | Picks that reference outfit colours | |
| T9 | Empty or zero budget | Budget 0 | "Enter a budget greater than 0." | |
| T10 | Non-image upload | A .pdf in the photo field | "Upload an image under 4 MB." | |
| T11 | AI unavailable | Remove or break GEMINI_API_KEY | Default split, marked as AI unavailable | |
| T12 | History | After T5 to T7 | All plans listed, newest first | |
| T13 | Session routes | /session-info and /session-data while logged in | JSON with user and query count | |

## Quality checks on AI output
- Total of picks stays within about 5% of the budget (a warning shows otherwise)
- Platforms match the category (Swiggy and Zomato for parties, IKEA for home)
- Each pick has a price, a reason and a working search link

## Screenshots
Add files such as `home-result.png`, `party-result.png`, `jewelry-result.png`, `history.png`.
