# Phase 2: Requirement Analysis

## Functional requirements
| ID | Requirement |
|---|---|
| FR1 | Users can register, log in and log out |
| FR2 | Home planner accepts budget, rooms, quantities and style |
| FR3 | Party planner accepts budget, guest count, event type and venue |
| FR4 | Jewelry planner accepts budget, occasion, style and an optional outfit image |
| FR5 | System returns recommendations with name, category, platform, estimated price and reason |
| FR6 | Each recommendation links to a search on its platform |
| FR7 | Every request is saved and shown on the History and Dashboard pages |
| FR8 | Default recommendations are shown if Gemini fails or returns nothing usable |
| FR9 | Invalid input (missing or zero budget, bad image) shows a clear error |

## Non-functional requirements
- **Security:** passwords stored as salted PBKDF2 hashes; JWT session cookie (HttpOnly); API key kept in `.env`, not in code or GitHub
- **Performance:** results within a few seconds for typical requests
- **Usability:** responsive layout that works on phone and desktop
- **Reliability:** the app keeps working when the AI service is unreachable
- **Maintainability:** AI logic isolated in `gemini_utils.py`

## Technology stack
| Layer | Technology |
|---|---|
| Backend | Python, FastAPI, Uvicorn |
| AI | Google Gemini (`google-genai` SDK), text + image input |
| Database | SQLite |
| Frontend | HTML, CSS, Jinja2 templates |
| Auth | PyJWT, PBKDF2 password hashing |
| Tools | VS Code, Git, GitHub |

## Software requirements
Python 3.10+, a free Gemini API key from aistudio.google.com, a web browser.

## Assumptions and limits
- Prices are AI estimates, not live store prices
- Links open a search on the platform, they are not direct product pages
