# Phase 7: Project Documentation

## 1. Introduction
PocketSmart AI is a GenAI-powered assistant that gives budget-based recommendations for home interiors, parties and jewelry using Google Gemini.

## 2. Objectives
- Turn a single budget into a structured, category-wise plan
- Use text and image input to personalise results
- Provide a simple, secure, multi-user web app

## 3. System overview
See Phase 3 for the architecture. The FastAPI backend receives form data, the Gemini layer produces JSON recommendations, and results are stored in SQLite and shown as cards.

## 4. Implementation summary
- **Authentication:** registration, login, logout, JWT token endpoint, salted password hashing
- **Planners:** Home, Party and Jewelry, each with its own prompt and platform list
- **Multimodal:** the Jewelry planner sends the outfit photo to Gemini along with the text prompt
- **Reliability:** output is validated and fallback recommendations are used if the AI fails
- **History:** every result is saved per user

## 5. User guide
1. Register, then log in.
2. Choose a planner from the top menu.
3. Enter your budget and details, then press **Get recommendations**.
4. Open a card's link to search that item on the platform.
5. Find earlier plans on **Dashboard** and **History**.

## 6. Limitations
- Prices are AI estimates and links are search pages
- Quality depends on the Gemini model and the details entered

## 7. Future scope
- Live price data through official partner APIs
- Save favourite items and compare plans
- More planners (travel, wardrobe, gifts)
- Cloud deployment

## 8. Conclusion
PocketSmart AI shows how a generative model, wrapped in validated forms and a fallback path, can give useful budget planning in a small web app.

## 9. Tools and references
FastAPI, Uvicorn, Jinja2, PyJWT, SQLite, Google Gemini API (google-genai), VS Code, Git and GitHub.
