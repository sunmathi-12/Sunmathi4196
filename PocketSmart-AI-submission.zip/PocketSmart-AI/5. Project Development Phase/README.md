# Phase 5: Project Development

Source code for PocketSmart AI lives in this folder.

| File | Role |
|---|---|
| main.py | FastAPI app: auth, planner routes, history, session routes |
| gemini_utils.py | Prompts, Gemini call (text + image), validation, fallback |
| requirements.txt | Python dependencies |
| .env.example | Template for your keys (copy to `.env`) |
| templates/ | Jinja2 pages |
| static/style.css | Styling |

## Run locally
```
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
copy .env.example .env
python main.py
```
Then open http://127.0.0.1:8000. Never commit your real `.env`.
