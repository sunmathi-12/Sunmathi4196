# Phase 3: Project Design

## Architecture
```
Browser (HTML/CSS/Jinja2)
        |  form POST
        v
FastAPI backend (main.py)
  - auth: /register /login /logout /token
  - planners: /generate-home /generate-party /generate-jewelry
  - data: /history /dashboard /recommendations-details /session-info /session-data
        |                         |
        v                         v
gemini_utils.py            SQLite (users, history)
  - builds prompt
  - calls Gemini (text + image)
  - validates JSON, adds store links
  - fallback if AI fails
        |
        v
Google Gemini API
```

## Data flow
1. User logs in and opens a planner.
2. The form is submitted to its `/generate-*` route with the budget, details and optional image.
3. The backend validates the input, then `gemini_utils.recommend()` builds a prompt for that category.
4. Gemini returns JSON with a summary and a list of picks.
5. Each pick is checked, given a platform search link, and totalled. If anything fails, default recommendations are used.
6. The result is saved to the `history` table and shown as cards.

## Database design
**users**: id, username (unique), password (salt + hash)
**history**: id, user_id, category, budget, result (JSON), created

## API routes
| Route | Method | Purpose |
|---|---|---|
| /register, /login | GET, POST | Create account, sign in |
| /logout | GET | End session |
| /token | POST | Issue JWT for API clients |
| /planner/{home,party,jewelry} | GET | Show planner form |
| /generate-home, /generate-party, /generate-jewelry | POST | Produce recommendations |
| /dashboard, /history | GET | Recent and full history |
| /recommendations-details?id= | GET | One saved result as JSON |
| /session-info, /session-data | GET | Session details and usage summary |

## UI pages
index, auth (login/register), planner (one template for all three), history/dashboard, shared base layout and result cards.

## Design decisions
- One planner template driven by a config, so all three forms stay consistent
- Fallback recommendations so the demo never shows a blank page
- Search links instead of scraped data for legal and reliability reasons
